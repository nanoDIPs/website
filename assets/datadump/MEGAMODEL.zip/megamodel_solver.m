function dydt = megamodel_solver(t,uin,p,lengthCell,delX,tspanvalue)

nVar = 5; % number of equations in the system
nx = lengthCell/delX;

% unfold input vector into (nVar x nx) size matrix
u = zeros((nVar+1), nx);
for m = 1:(nVar + 1)
    u(m, :) = uin(((m-1)*nx+1):(m*nx));
end

% PARAMETERS
%===Eqn. 1: d[d_ecm]/dt===%
kd_ex_ecm = p(1);   %Rate constant of drug exchange into ECM
kd_ex_c = p(2);
k_open = p(5); 
death_d = p(6);
death_v = p(7);
%===Eqn. 2: d[d_c]/dt===%
%all defined above
%===Eqn. 3: d[v_ecm]/dt===%
kv_ex_ecm = p(3);
kv_ex_c = p(4);
%===Eqn. 4: d[v_c]/dt===%
%all defined above
%===Eqn. 5: d[p]/dt===%
death_p = p(8);
%k_kill = p(9); %Rate constant for [protease] death in presence of drug

Dd_ecm = p(9);
Dd_c = p(10);
Dv_ecm = p(11);  %Diffusion constant for vesicles in ECM
Dv_c = p(12);
Dp = p(13);

% RESTRICT CONCENTRATIONS TO ONLY +VE VALUES
for k = 1:5
    for m = 1:nx 
        if u(k, m) < 0
            u(k, m) = 0;
        end
    end
end

u_d_ecm = u(1,:);  %Concentration of drug in ecm
u_d_c = u(2,:);
u_v_ecm = u(3,:);
u_v_c = u(4,:);
u_p = u(5,:);
tumour_state = u(6, :);

% INITIALISE MATRICES
d2d_ecm_dx2 = zeros(size(u_d_ecm));    %double spacial derivate wrt x of [drug in ecm]
d2d_c_dx2 = zeros(size(u_d_c));
d2v_ecm_dx2 = zeros(size(u_v_ecm));
d2v_c_dx2 = zeros(size(u_v_c)); 
d2p_dx2 = zeros(size(u_p));
dv_c_dx = zeros(size(u_v_c));  %spacial derivative wrt x of [vesicle in capillary]
dd_c_dx = zeros(size(u_d_c));

u_reac = zeros(5, nx);  %matrix of reaction terms

tumour_activate = 0.01;
tumour_deactivate = 0.15;

for j = 1:nx   
    if j == 1
        if u_p(j+1) >= tumour_activate
            tumour_state(j) = 1;
        end
    elseif j == nx
        if u_p(j-1) >= tumour_activate
            tumour_state(j) = 1;
        end
    else
        if u_p(j+1) >= tumour_activate || u_p(j-1) >= tumour_activate
            tumour_state(j) = 1;
        end
    end
    
    if u_d_ecm(j) >= tumour_deactivate     %If [drug] at this point is high enough 
       tumour_state(j) = -10000;    %Deactivates tumour
    end   
end

% COMPUTE REACTION TERM
for i = 1:nx
   if i <= (nx/3)
       u_reac(1, i) = -(death_d .* u_d_ecm(i)) + death_v .* u_v_ecm(i);
       u_reac(2, i) = -(death_d .* u_d_c(i)) + death_v .* u_v_c(i);
       u_reac(3, i) = -(death_v .* u_v_ecm(i));
       u_reac(4, i) = -(death_v .* u_v_c(i));
       u_reac(5, i) = -(death_p .* u_p(i));
       
   else
        u_reac(1, i) = kd_ex_ecm .* u_d_c(i) - kd_ex_c .* u_d_ecm(i) + 50 .* k_open .* (u_v_ecm(i) .* u_p(i)) - death_d .* u_d_ecm(i) + death_v .* u_v_ecm(i);  %d_ecm
        u_reac(2, i) = kd_ex_c .* u_d_ecm(i) - kd_ex_ecm .* u_d_c(i) - death_d .* u_d_c(i) + death_v .* u_v_c(i);  %d_c
        u_reac(3, i) = kv_ex_ecm .* u_v_c(i) - kv_ex_c .* u_v_ecm(i) - k_open .* (u_v_ecm(i) .* u_p(i)) - death_v .* u_v_ecm(i);   %v_ecm
        u_reac(4, i) = kv_ex_c .* u_v_ecm(i) - kv_ex_ecm .* u_v_c(i) - death_v .* u_v_c(i);  %v_c
        
        if tumour_state(i) == 1
            u_reac(5, i) = 0.005 -(death_p .* u_p(i));
        else
            u_reac(5, i) = -(death_p .* u_p(i));
        end
   end
end   

% COMPUTE DIFFUSION TERMS
for j = 1:nx   %ADD BCs IN HERE
    %calculate single & double derivatives
    if j == 1   %START BOUNDARY       
        %Phase 1 - Set first derivative wrt x as 0 for all species
        d2d_ecm_dx2(j) = 0;
        d2d_c_dx2(j) = 0;
        d2v_ecm_dx2(j) = 0;
        d2v_c_dx2(j) = 0;
        d2p_dx2(j) = 0;
        dv_c_dx(j) = 0;
        dd_c_dx(j) = 0;    
        
    elseif j == nx      %END BOUNDARY
        d2d_ecm_dx2(j) = d2d_ecm_dx2(j-1);
        d2d_c_dx2(j) = d2d_c_dx2(j-1);
        d2v_ecm_dx2(j) = d2v_ecm_dx2(j-1);
        d2v_c_dx2(j) = d2v_c_dx2(j-1);
        d2p_dx2(j) = d2p_dx2(j-1);
%        dv_c_dx(j) = 0;
%        dd_c_dx(j) = 0;

        dv_c_dx(j) = (u_v_c(j) - u_v_c(j-1))/(delX);
        dd_c_dx(j) = (u_d_c(j) - u_d_c(j-1))/(delX);

    else    %calculate first/second derivative
        d2d_ecm_dx2(j) = (u_d_ecm(j+1) + u_d_ecm(j-1) - 2*u_d_ecm(j))/delX^2;
        d2d_c_dx2(j) = (u_d_c(j+1) + u_d_c(j-1) - 2*u_d_c(j))/delX^2;
        d2v_ecm_dx2(j) = (u_v_ecm(j+1) + u_v_ecm(j-1) - 2*u_v_ecm(j))/delX^2;
        d2v_c_dx2(j) = (u_v_c(j+1) + u_v_c(j-1) - 2*u_v_c(j))/delX^2;
        d2p_dx2(j) = (u_p(j+1) + u_p(j-1) - 2*u_p(j))/delX^2;
        
        dv_c_dx(j) = (u_v_c(j) - u_v_c(j-1))/(delX);    
        dd_c_dx(j) = (u_d_c(j) - u_d_c(j-1))/(delX);    
    end
end

% COMPUTE CONVECTIVE TERMS
vel = 1;   %blood velocity in capillary in mm/s 
conv_d_c = vel .* dd_c_dx;
conv_v_c = vel .* dv_c_dx;

% sum reaction and diffusion terms and fold results into a column vector
dydt = [u_reac(1, :)' + (Dd_ecm .* d2d_ecm_dx2');  %d_ecm term
        u_reac(2, :)' + (Dd_c .* d2d_c_dx2') - conv_d_c';   %Only have flow in capillary
        u_reac(3, :)' + (Dv_ecm .* d2v_ecm_dx2');  
        u_reac(4, :)' + (Dv_c .* d2v_c_dx2') - conv_v_c';
        u_reac(5, :)' + (Dp .* d2p_dx2');
        tumour_state'];
    
global h
try
    waitbar(t/tspanvalue,h,'Calculating...')
    if t/tspanvalue == 1
        delete(h)
    end
catch
    if t/tspanvalue ~= 1
        h = waitbar(0);
    elseif t/tspanvalue == 1
        delete(h)
    end
end
end
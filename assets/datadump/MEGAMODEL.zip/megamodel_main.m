clear; clc
pause on;
nvar = 5; % how many equations

%WORKING IN MM AND S
%kd_ex_ecm - kd_ex_c - kv_ex_ecm - kv_ex_c 
%k_open - death_d - death_v - death_ p - k_kill 
%Dd_ecm - Dd_c - Dv_ecm - Dv_c - Dp 
p = [1e-2 1e-2 5e-2 5e-2...
    1.85e6 1.5e-4 1e-2 1e-3...  %CHANGE FIRST VALUE HERE!!!!!!!!!!!!!!!!!!!!!!!!!!!
    1e-4 1e-3 1e-5 1e-4 1e-4];

lengthCell = 30; %length of modelled thing in mm
nx = 90; %absolute number of points
dx = lengthCell / nx;
tspan = [0 30]; %time modelled in seconds

%===[Protease] initial condition===%
%Phase 1 - single point of mass, that diffuses out in ECM as time passes
initial = zeros(nx, nvar + 1);

initial((63), 5) = initial((63), 5) + 0.1;
initial(64, 5) = initial(64, 5) + 0.03;
initial(62, 5) = initial(62, 5) + 0.03;

%===[Vesicles in Cap] initial condition===%
%Phase 1 - lump of vesicles enter capillary at t=0
%initial(1, 4) = initial(1, 4) + 0.05;  %Adds constant input level 
initial(2, 4) = initial(2, 4) + 0.5;    %Adds lump of vesicles that move through system

% INITIALISE TUMOUR STATE
for k = 1:nx
    if k < 56
        initial(k, 6) = 0;
    elseif k > 72
        initial(k, 6) = 0;
    else
        initial(k, 6) = 1;
    end            
end

y0 = reshape(initial, [nx * (nvar+1), 1]);
%d_ecm - d_c - v_ecm - v_c - p
%y0 = [0 0 0 V-IC P-IC];    %Steady state values - used for ICs 
opts = odeset('MaxStep', 1e-1);  %Keep max step small for precise diffusion

[tsol, ysol] = ode15s(@(t, y)megamodel_solver(t, y, p, lengthCell, dx, (max(tspan)-min(tspan))), tspan, y0, opts); 
%At time t, position y, the ode function is given by megamodel_solver, for a time span tspan, and initial condition y0 for the first iteration (ode option - opts)
%Result is a matrix of time x (nvar * nx)

space = linspace(0, lengthCell, nx);    %linearly spaced vector from 0 to 4 (lengthCell), with 40 (nx) spaces
%tmin = tsol ./ 60;

%Split ysol for plotting/averaging 
for varplot = 1:6
    inter = (varplot - 1) * nx + 1;
    interend = varplot * nx; 
    specie_columns = inter:interend;
    if varplot == 1 
        d_ecm_sol = ysol(1:size(ysol, 1), specie_columns);%First 40 columns in ysol -> d_ecm, each column is point in space with value changing with time as you go down the rows
    elseif varplot == 2
        d_c_sol = ysol(1:size(ysol, 1), specie_columns);
    elseif varplot == 3
        v_ecm_sol = ysol(1:size(ysol, 1), specie_columns);
    elseif varplot == 4
        v_c_sol = ysol(1:size(ysol, 1), specie_columns);
    elseif varplot == 5 
        p_sol = ysol(1:size(ysol, 1), specie_columns);
    else 
        tumour_sol = ysol(1:size(ysol, 1), specie_columns);
    end
end

% RESET TUMOUR VALUES
for m = 1:90
    for n = 1:size(ysol, 1)
       if tumour_sol(n, m) > 0
           tumour_sol(n, m) = 0.5;
       elseif n ~= 1
           if tumour_sol(n, m) < tumour_sol((n-1), (m))
               
               tumour_sol(n, m) = 0;
           end
       end
    end
end

figure();
set(gcf,'units','normalized','outerposition',[0 0 1 1]);
pause(1);   
%(size(ysol, 1) - 5)
for m = 1:size(ysol, 1)
   plot(space, d_ecm_sol(m, :), 'c',...
       space, d_c_sol(m, :), 'r',...
       space, v_ecm_sol(m, :), 'b',...
       space, v_c_sol(m, :), 'g',... 
       space, p_sol(m, :), 'k');
   hold on;
   scatter(space, tumour_sol(m, :));
   ylim([0 1])
   hold off;
   drawnow;
   pause(0.001);
end

xlabel('Length (mm)');
ylabel('Concentration of Specie (M)');
legend('Drug in ECM', 'Drug in Capillary', 'Liposomes in ECM',...
    'Liposomes in Capillary', 'Protease', 'Tumour State');

